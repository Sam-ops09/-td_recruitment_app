package com.example.td_recruitment_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
